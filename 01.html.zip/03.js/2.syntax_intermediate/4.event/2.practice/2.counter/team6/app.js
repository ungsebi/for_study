const countValue = document.getElementById('value');
// const countButtons = document.getElementsByClassName('btn');
const countButtons = document.querySelectorAll('button');
console.log(countButtons);

// const [decreaseButton, resetButton, increaseButton] = countButtons;

// const fish = ['shark', 'whale', 'koi', 'nimo'];

// for (let i = 0; i < fish.length; i++) {
//     console.log(fish[i]);
// }

// forEach() -> array 객체가 가지고 있는 method 
// fish.forEach(aFish => {
//     console.log(aFish);
// });

let count = 0;

countButtons.forEach(button => {
    button.addEventListener('click', (event) => {
        const currentTarget = event.currentTarget;
        // console.dir(currentTarget); // classList 프로퍼티 확인

        const styles = currentTarget.classList[1];
        count = styles !== 'reset' ? (count = styles === 'decrease' ? --count : ++count) : 0;

        let countValueColor = '';
        countValueColor = count !== 0 ? (countValueColor = count > 0 ? 'green' : 'red') : 'grey';

        countValue.textContent = count;
        countValue.style.color = countValueColor;
    });
});