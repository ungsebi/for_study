const btn1 = document.getElementById('decrease');
const btn2 = document.getElementById('reset');
const btn3 = document.getElementById('increase');

const count = document.getElementById('count');

let num = 0;

btn1.addEventListener('click', () => {
    num = num - 1;
    count.textContent = num;
    checkColor(num);
});

btn2.addEventListener('click', () => {
    num = 0;
    count.textContent = num;
    checkColor(num);
});

btn3.addEventListener('click', () => {
    num = num + 1;
    count.textContent = num;
    checkColor(num);
});

function checkColor(num){
    if(num > 0) {
        count.style.color = 'rgb(0, 255, 0)';
    } else if(num < 0){
        count.style.color = 'rgb(255, 0, 0)';
    } else{
        count.style.color = 'rgb(204, 204, 204)';
    }
}