let num = 0;

function count(type)  { // 함수명은 조금 더 서술적으로 무엇을 count? ex) countNumber(), type도 조금 더 구체적인 용어로
    // 결과를 표시할 element
    const resultElement = document.getElementById('result');

    // 현재 화면에 표시된 값 --> ???

    // 더하기/빼기
    if(type === 'plus') {
        num = num + 1; // num += 1
    }else if(type === 'minus')  {
        num = num - 1;
    }else if(type === 'reset'){
        num = 0;
    }

    if(num > 0){
        resultElement.style.color = 'green';
    }else if (num < 0){
        resultElement.style.color = 'red';
    }else{
        resultElement.style.color = 'black';
    }

        // 결과 출력
        resultElement.innerText = num;
}