let number = 0;
const btnDecrease = document.getElementById("decrease");
const btnReset = document.getElementById("reset");
const btnIncrease = document.getElementById("increase");

function decreaseNumber() { 
    number = number-1;
    numberColor();
}

function resetNumber() {
    number = 0;
    numberColor();
}

function increaseNumber() {
    number = number+1;
    numberColor();
}

function numberColor() {
    const num = document.getElementById("number");
    num.textContent = number;

    if(number == 0){
        num.style.color = 'rgb(126, 126, 126)';
    }
    else if(number > 0){
        num.style.color = 'rgb(0, 200, 3)';
    }
    else{
        num.style.color = 'rgb(255, 0, 0)';
    }
}

btnDecrease.addEventListener('click', decreaseNumber);

btnReset.addEventListener('click', resetNumber);

btnIncrease.addEventListener('click', increaseNumber);