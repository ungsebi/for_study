const decreaseBtn = document.getElementById('decreaseBtn');
const resetBtn= document.getElementById('resetBtn');
const increaseBtn = document.getElementById('increaseBtn');
const num = document.getElementById('num');

let countNum = num.innerText;

decreaseBtn.addEventListener('click', DecreaseBtn());
resetBtn.addEventListener('click', ResetBtn());
increaseBtn.addEventListener('click', IncreaseBtn());

function FontColor(){
    if(num.innerText<0){
        num.style.color = 'rgb(255,0,0)';
    }else if(num.innerText==0){
        num.style.color = 'rgb(0,0,0)';
    }else if(num.innerText>0){
        num.style.color = 'rgb(0,0,255)';
    }
}


function DecreaseBtn(color){
    countNum = parseInt(countNum)-1;
    num.innerText = countNum;
}

function ResetBtn(color){
    countNum=0;
    num.innerText = countNum;
}

function IncreaseBtn(color){
    countNum = parseInt(countNum)+1;
    num.innerText = countNum;
}