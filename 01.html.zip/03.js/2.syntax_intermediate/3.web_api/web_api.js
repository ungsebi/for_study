// window 객체
console.log(window);

// alert('hello'); // window는 생략 가능

console.log(window.innerWidth); // 현재 window의 너비값

// BOM 객체

// Localtion object, 현재 문서의 경로(URL)을 나타냄
console.log(location);

console.log(location.href);

// location.href = 'https://www.naver.com';
// href프로퍼티는 내부적으로 location.assign('https://www.naver.com')이 호출됨