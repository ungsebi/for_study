console.log(typeof 5);
console.log(typeof 5.5);

console.log(typeof '문자열');

const userName = 'Yoo';

console.log('저는', userName, '입니다');
console.log('저는 ' + userName + ' 입니다.');
console.log(`저는 ${userName} 입니다.`); // `(backtick, 백틱 기호), template literal 방식