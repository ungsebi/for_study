// 한 줄 주석
/* 여러 줄 
   주석
*/

// JS 코드만 작성하는 부분

/**
 * Javascript에서의 변수 키워드(keyword, 예약어)
 * var, let, const
 * 
 * JS는 동적 타입 언어
 * Java는 정적 타입 언어
 * 
 * 변수 네이밍 규칙 : camelCase(Java와 동일)
 * 
 * let : 재할당이 가능
 * const(constants): 재할당 불가 (Java에서의 final)
 */


// 변수(variable)
let userName = 'Yoo'; // 문자열에 홑따옴표(single quote) 사용 가능
console.log(userName); // browser console에 출력하는 방식

userName = 'Why'; // 재할당(Reassign), 재할당 시에는 let 키워드를 다시 쓰지 않아도 됨
console.log(userName);

// 상수(Constants)
const allUsers = 20;

// allUsers = 5; // Uncaught TypeError: Assignment to constant variable

// 일단 무조건 const로 변수를 만들고 작성, 작성 과정 중에 특정 변수는 재할당이 필요할 것 같아 보이면, 그때 그 변수만 let으로 변경
